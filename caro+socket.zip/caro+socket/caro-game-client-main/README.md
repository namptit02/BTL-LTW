# caro-game-client
Giới thiệu, chạy demo: https://youtu.be/87tKJgvUkMk
Link server: https://github.com/Duc-ju/caro-game-server
